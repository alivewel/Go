src
===

.. toctree::
   :maxdepth: 7

   all_maps
   character_classes
   fill_data
   game_bot_buttons
   load_data
   load_all
   tables
