about game module
=================

.. automodule:: about
    :members:
    :undoc-members:
    :show-inheritance: