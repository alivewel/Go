starting bot module
===================

.. automodule:: starting_bot
    :members:
    :undoc-members:
    :show-inheritance: