character_classes module
===============

.. automodule:: character_classes
    :members:
    :undoc-members:
    :show-inheritance: