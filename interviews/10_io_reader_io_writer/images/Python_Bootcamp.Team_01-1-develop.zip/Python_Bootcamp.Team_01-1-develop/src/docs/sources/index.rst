Welcome to team01`s documentation!
==================================

.. toctree::
    :maxdepth: 2
    :caption: Contents

    starting_bot
    about
    modules


Indices and Tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`