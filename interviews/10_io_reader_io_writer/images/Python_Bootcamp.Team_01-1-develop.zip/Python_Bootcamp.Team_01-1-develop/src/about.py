"""
Welcome to the game “Condottiers vs. Corsairs”!\n
You will have to choose who you want to join and then start the walkthrough.\n
For the Condottiers, you will have to find out who stole the king's cat, encountering obstacles along the way.\n
For the Corsairs, you will have to defend your presumption of innocence while dealing with the Condottiers.\n
We strongly recommend buying food from npcs.\n
After battles you will have something to replenish health, armor and increase temporary damage.\n
Have fun!
"""
